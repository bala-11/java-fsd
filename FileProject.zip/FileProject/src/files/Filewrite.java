package files;
import java.io.*;
public class Filewrite {
	  public static void main(String[] args) {
	    try {
	      FileWriter fo = new FileWriter("File1.txt");
	      fo.write("Hello World");
	      fo.close();
	      System.out.println("Successfully wrote to the file.");
	    }
	    catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }
	}
