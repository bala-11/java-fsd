package files;
import java.util.*;
import java.io.*;
public class FileRead {
	  public static void main(String[] args) {
	    try {
	      File fo = new File("File1.txt");
	      Scanner sc = new Scanner(fo);
	      while (sc.hasNextLine()) {
	        String data = sc.nextLine();
	        System.out.println(data);
	      }
	      sc.close();
	    } catch (FileNotFoundException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }
	}