package com.example;

import org.testng.annotations.Test;

public class NewTest {
	  String trackID=null;
	@Test(priority = 1)
		public void createId() {
			System.out.println("creation of ID");
			trackID="abcd";
		}
		@Test(priority = 2,dependsOnMethods = {"createId"})
		public void trackShipping() {
		
			if(trackID!=null) {
				System.out.println("shipping is in progress");
			}
			else {
				System.out.println("shipping is failed");
			}
		}
		@Test(priority = 3,dependsOnMethods = {"createId"})
		public void cancelShipping() {
			if(trackID!=null) {
				System.out.println("cancelshipping is in progress");
			}
			else {
				System.out.println("cancelshipping is failed");
			}
		}

	}
