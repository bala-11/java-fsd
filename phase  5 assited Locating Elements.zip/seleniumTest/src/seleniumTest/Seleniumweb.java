package seleniumTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Seleniumweb {
	public static void main (String []args) {
		System.setProperty("webdriver.chrome.driver", "P:\\95\\chromedriver.exe");
		WebDriver wb = new ChromeDriver();
		System.out.println(wb);
		
		//maximize the screen
		 wb.manage().window().maximize();
		 
		 wb.get("https://www.amazon.in/");
		 
			System.out.println(wb.getCurrentUrl());
			System.out.println(wb.getTitle());
			
			//close the browser
			//wb.close();

	}
	
}
