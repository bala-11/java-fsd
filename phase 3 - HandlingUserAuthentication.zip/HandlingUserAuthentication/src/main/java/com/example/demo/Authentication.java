package com.example.demo;

public class Authentication {
	

	public boolean Validate(String username, String Password)
	{
		if(username.equals("Balaji") && Password.equals("1894"))
		return true;
		else return false;
	}

}