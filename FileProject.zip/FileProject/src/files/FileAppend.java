package files;
import java.util.*;
import java.io.*;
public class FileAppend {

	public static void main(String[] args) throws IOException{
		String path="C:\\Users\\balaj\\Files\\";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Filename");
		String filename=sc.next();
		String finalpath=path+filename;
		File f=new File(finalpath);	
		
		//create a new file
		boolean b=f.createNewFile();
		if(b!=true) {
			System.out.println("file added");
		}
		else {
			System.out.println("file not added");
	}

}
}