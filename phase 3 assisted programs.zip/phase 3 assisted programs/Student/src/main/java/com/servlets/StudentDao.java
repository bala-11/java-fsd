package com.servlets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/*CRUD - DAO(data access object)
Call the DBUtil for dB connection
Continue with 
3.Statement of sql
4.execute the statements
5.close the connections  
 */
public class StudentDao {
	
	
	//insert ,update,delete
	public int insert(Student s) throws ClassNotFoundException, SQLException {
		Connection con=DBUtil.getCon();
		if(con!=null) {
			System.out.println("connection is established");
		}
		else {
			System.out.println("connection failed");
		}
		
//		Statement st=con.createStatement();
//		String sql="insert into student values("+s.getSid()+","+"'"+s.getSname()+"'"+","+"'"+s.getSemail()+"')";
//		//insert,update,delete->int value -no of rows
//		int row=st.executeUpdate(sql);
		String sql="insert into student values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, s.getSid());
		ps.setString(2, s.getSname());
		ps.setString(3, s.getSemail());
		int row=ps.executeUpdate();
		return row;
	
	}
	
	public ResultSet retrieve() throws ClassNotFoundException, SQLException {
		Connection con=DBUtil.getCon();
		if(con!=null) {
			System.out.println("connection is established");
		}
		else {
			System.out.println("connection failed");
		}
		Statement st=con.createStatement();
		String sql="select * from student";
		//select
		ResultSet rs=st.executeQuery(sql);
		return rs;
	}

}
