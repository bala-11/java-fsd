package com.example.AgeValidator;

import static org.junit.Assert.*;

import org.junit.Test;

public class AgeTest {

	@Test
	public void test() {
		/*if the expected output==actual output- pass
		 * if the expected output!=actual output-fail-bugs
		 *  */
		AgeValidator agevalid=new AgeValidator();
		assertEquals("right to vote", agevalid.ageValid(17));
	}

}

