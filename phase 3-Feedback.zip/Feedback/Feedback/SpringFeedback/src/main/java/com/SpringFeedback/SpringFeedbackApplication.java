package com.SpringFeedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFeedbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFeedbackApplication.class, args);
	}

}
