package files;
import java.io.*;
public class FileCreate {
	  public static void main(String[] args) {
	    try {
	      File fo = new File("File1.txt");
	      if (fo.createNewFile()) {
	        System.out.println("File created: " + fo.getName());
	      } else {
	        System.out.println("File already exists.");
	      }
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }
	}
