package com.SpringFeedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
